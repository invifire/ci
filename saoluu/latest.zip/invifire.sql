-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jan 04, 2013 at 02:39 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `invifire`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `asset`
-- 

DROP TABLE IF EXISTS `asset`;
CREATE TABLE IF NOT EXISTS `asset` (
  `idasset` bigint(20) unsigned NOT NULL,
  `nameasset` text NOT NULL,
  `url` text NOT NULL,
  `idowner` int(10) unsigned NOT NULL,
  `album` text,
  `time` int(10) NOT NULL,
  PRIMARY KEY  (`idasset`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `asset`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `book`
-- 

DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `idbook` int(10) unsigned NOT NULL auto_increment,
  `idtile` int(10) unsigned default NULL,
  `title` text NOT NULL,
  `noidung` text NOT NULL,
  `author` text NOT NULL,
  `iduser` text NOT NULL,
  `tilestyle` tinyint(4) NOT NULL default '0',
  `reviewedtime` int(10) unsigned NOT NULL default '0',
  `rating` tinyint(2) unsigned NOT NULL default '4',
  `voteup` int(10) unsigned NOT NULL default '0',
  `reviewpeople` tinyint(2) unsigned NOT NULL default '0',
  `show` float NOT NULL default '1',
  PRIMARY KEY  (`idbook`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

-- 
-- Dumping data for table `book`
-- 

INSERT INTO `book` VALUES (16, 22, 'THE DAUGHTER OF HUANG CHOW', 'THE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax Rohmer', 'Sax Rohmer', '9', 0, 1352557990, 3, 0, 0, 1);
INSERT INTO `book` VALUES (17, 23, 'THE LOST SPECIAL', '', 'Sir Arthur Conan Doyle', '9', 0, 1352558614, 3, 0, 0, 1);
INSERT INTO `book` VALUES (18, 24, 'THE STORM OF BADAJOZ', '', 'W.H. Maxwell', '9', 0, 1352558739, 3, 0, 0, 1);
INSERT INTO `book` VALUES (19, 25, 'The Lost Trail', '', 'Edward S. Ellis', '9', 0, 1352558888, 3, 0, 0, 1);
INSERT INTO `book` VALUES (20, 26, 'Man and Superman', '', 'George Bernard Shaw', '9', 0, 1352558936, 3, 0, 0, 1);
INSERT INTO `book` VALUES (21, 27, 'Fred Fearnot''s Day, or The Great Reunion at Avon', '', 'Hal Standish', '9', 0, 1352559015, 3, 0, 0, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `ci_sessions`
-- 

DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL default '0',
  `ip_address` varchar(45) NOT NULL default '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `user_data` text NOT NULL,
  PRIMARY KEY  (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `ci_sessions`
-- 

INSERT INTO `ci_sessions` VALUES ('1047be28a234fbe79272ea7fa93e2476', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357130487, 'a:4:{s:9:"user_data";s:0:"";s:5:"email";s:13:"demo@demo.com";s:5:"lname";s:4:"Last";s:5:"fname";s:5:"First";}');
INSERT INTO `ci_sessions` VALUES ('c7f31d0b3b486923c1dbe1df00f53ad7', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0; MSAppHost/1.0)', 1357130109, '');
INSERT INTO `ci_sessions` VALUES ('0a148f7acbbde92db59e725234319346', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0; MSAppHost/1.0)', 1357130109, 'a:5:{s:9:"user_data";s:0:"";s:5:"email";s:13:"demo@demo.com";s:5:"lname";s:4:"Last";s:5:"fname";s:5:"First";s:8:"loggedin";b:1;}');
INSERT INTO `ci_sessions` VALUES ('12c3d4e093e269dca2165ef10ee456ae', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357130487, '');
INSERT INTO `ci_sessions` VALUES ('02a1586856c7d7ef9dfeffea11289ba7', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357182940, '');
INSERT INTO `ci_sessions` VALUES ('917ab85842e70ce1a05eeb75cd54d64f', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357182940, '');
INSERT INTO `ci_sessions` VALUES ('f5583a382a149c4207ba016626cc0142', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357182940, '');
INSERT INTO `ci_sessions` VALUES ('953a1e939972dcdf6f26501bcec50244', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357182940, 'a:4:{s:9:"user_data";s:0:"";s:5:"email";s:13:"demo@demo.com";s:5:"lname";s:4:"Last";s:5:"fname";s:5:"First";}');
INSERT INTO `ci_sessions` VALUES ('f8bcf0dbd3cf20ecec6431752ba024ec', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357130028, '');
INSERT INTO `ci_sessions` VALUES ('0302a4956321da814ae57bb29ece2082', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0; MSAppHost/1.0)', 1357122115, '');
INSERT INTO `ci_sessions` VALUES ('d8b1babad84b0f9ad2d0d85f8c0a6549', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357122011, '');
INSERT INTO `ci_sessions` VALUES ('49cc996ce6b3e84c3b1fa787a12c418b', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11', 1357121714, '');
INSERT INTO `ci_sessions` VALUES ('2451fe9a6ddf4dcf99c8fd405b64a9ee', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0; MSAppHost/1.0)', 1357122115, '');
INSERT INTO `ci_sessions` VALUES ('2987a63c8ee5ba06c350b46be7829c00', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357121686, '');
INSERT INTO `ci_sessions` VALUES ('5088b1917f4f0db1b5b35b2cf8d07984', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357121381, '');
INSERT INTO `ci_sessions` VALUES ('b9276ce22a9adb7cb962f2b4e6444fde', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0; MSAppHost/1.0)', 1357121543, 'a:5:{s:9:"user_data";s:0:"";s:5:"email";s:13:"demo@demo.com";s:5:"lname";s:4:"Last";s:5:"fname";s:5:"First";s:8:"loggedin";b:1;}');
INSERT INTO `ci_sessions` VALUES ('17779c9578a60d76fedbe15ee93cadb1', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357122011, '');
INSERT INTO `ci_sessions` VALUES ('de8ef076fc1c311efdd0a81ec6a00447', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11', 1357121714, '');
INSERT INTO `ci_sessions` VALUES ('544d2ab9290edef21ed3ee0a529a60d0', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357117543, '');
INSERT INTO `ci_sessions` VALUES ('b2060c15a096d83f4e927ea4c3e9ac90', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357118885, '');
INSERT INTO `ci_sessions` VALUES ('c261b07a4f7153c56ede220318bc60f0', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0; MSAppHost/1.0)', 1357117949, '');
INSERT INTO `ci_sessions` VALUES ('6f5f4dd2e660de6be9632cc135a9d9b4', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0; MSAppHost/1.0)', 1357121006, '');
INSERT INTO `ci_sessions` VALUES ('f334e79d028e07fdf8d2acb4af84711d', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)', 1357118052, '');
INSERT INTO `ci_sessions` VALUES ('ab47936091bf460ed1468d9d78ea51fd', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)', 1357118052, '');
INSERT INTO `ci_sessions` VALUES ('075043ba025eae96aa015de83d7ebfba', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357119417, '');
INSERT INTO `ci_sessions` VALUES ('dd64a6a9342d0ca924ccd147a6de4c31', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357120598, '');
INSERT INTO `ci_sessions` VALUES ('b17c7595037ce3aa63ca4ebe93ee6195', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357207046, '');
INSERT INTO `ci_sessions` VALUES ('d39f078f19500e0a8a6e19f9e1a100e5', '127.0.0.1', 'Opera/9.80 (Windows NT 6.2) Presto/2.12.388 Version/12.12', 1357207047, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `grouptile`
-- 

DROP TABLE IF EXISTS `grouptile`;
CREATE TABLE IF NOT EXISTS `grouptile` (
  `idgroup` int(10) unsigned NOT NULL auto_increment,
  `idtile` int(10) unsigned NOT NULL default '0',
  `gposition` int(10) unsigned NOT NULL default '0',
  `title` text NOT NULL,
  `subtitle` text NOT NULL,
  PRIMARY KEY  (`idgroup`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `grouptile`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tile`
-- 

DROP TABLE IF EXISTS `tile`;
CREATE TABLE IF NOT EXISTS `tile` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `iduser` int(10) unsigned NOT NULL default '0',
  `position` int(10) unsigned default '0',
  `idgroup` int(10) unsigned default '0',
  `commentcout` int(10) unsigned default '0',
  `imageurl` text,
  `logo` text,
  `brandinfo` text,
  `title` text,
  `subtitle` text,
  `tiletype` text,
  `tilestyle` text,
  `tilestatusnum` int(2) default '0',
  `tilestatusimg` int(2) default '0',
  `color` text,
  `colorgroup` int(2) default '0',
  `anitimeduration` int(2) default '0',
  `anitimeperiod` int(2) default '0',
  `anitimedirection` int(2) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `tile`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tilebook`
-- 

DROP TABLE IF EXISTS `tilebook`;
CREATE TABLE IF NOT EXISTS `tilebook` (
  `id` int(11) NOT NULL auto_increment,
  `iduser` int(11) NOT NULL,
  `title` text NOT NULL,
  `sizetile` text NOT NULL,
  `color` text NOT NULL,
  `imageurl` text NOT NULL,
  `commentcout` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

-- 
-- Dumping data for table `tilebook`
-- 

INSERT INTO `tilebook` VALUES (29, 9, 'yhtjtj', 'double', 'random', '', 0);
INSERT INTO `tilebook` VALUES (28, 9, 'Canh dong bat tan', '', 'random', 'images\\5.jpg', 0);
INSERT INTO `tilebook` VALUES (27, 9, 'Fred Fearnot''s Day, or The Great Reunion at Avon', 'double', 'random', 'images\\3.jpg', 0);
INSERT INTO `tilebook` VALUES (26, 9, 'Man and Superman', 'double', 'random', 'images\\3.jpg', 0);
INSERT INTO `tilebook` VALUES (25, 9, 'The Lost Trail', 'double', 'random', 'images\\3.jpg', 0);
INSERT INTO `tilebook` VALUES (24, 9, 'THE STORM OF BADAJOZ', 'double', 'random', 'images\\3.jpg', 0);
INSERT INTO `tilebook` VALUES (23, 9, 'THE LOST SPECIAL', '', 'random', 'images\\3.jpg', 0);
INSERT INTO `tilebook` VALUES (22, 9, 'THE DAUGHTER OF HUANG CHOW', 'double', 'random', 'images\\b1.jpg', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `iduser` int(10) unsigned NOT NULL auto_increment,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `pass` text NOT NULL,
  `salt` varchar(255) NOT NULL,
  `active` int(1) NOT NULL default '1',
  `level` int(1) NOT NULL default '2',
  `email` text NOT NULL,
  `imageurl` text,
  `ban` int(1) unsigned NOT NULL default '0',
  `add_date` datetime default NULL,
  `active_date` datetime default NULL,
  `update_date` datetime default NULL,
  `gender` int(1) NOT NULL,
  PRIMARY KEY  (`iduser`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (31, 'First', 'Last', '028c025d69203aa4406882a7d28f56a8', 'eGkkz', 1, 2, 'demo@demo.com', 'images/userdefault.png', 0, '2013-01-01 13:53:49', '2013-01-01 13:53:49', '2013-01-01 13:53:49', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `usersdetail`
-- 

DROP TABLE IF EXISTS `usersdetail`;
CREATE TABLE IF NOT EXISTS `usersdetail` (
  `iduser` int(10) unsigned NOT NULL,
  `fav` text NOT NULL,
  `follower` text NOT NULL,
  `following` text NOT NULL,
  `email` text NOT NULL,
  `imgstart` text NOT NULL,
  `imglockscr` text NOT NULL,
  `voteup` int(10) unsigned NOT NULL default '0',
  `votedown` int(10) unsigned NOT NULL default '0',
  `ban` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`iduser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `usersdetail`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `web`
-- 

DROP TABLE IF EXISTS `web`;
CREATE TABLE IF NOT EXISTS `web` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `iduser` int(10) unsigned NOT NULL default '0',
  `web` text NOT NULL,
  `title` text NOT NULL,
  `rating` float NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- 
-- Dumping data for table `web`
-- 

INSERT INTO `web` VALUES (1, 2, 'http://www.invifire.com', '<h1>Invifire</h1>', 0);
INSERT INTO `web` VALUES (2, 2, 'http://www.iviyshop.com', '', 0);
INSERT INTO `web` VALUES (3, 2, 'http://www.invifire.com', '', 0);
INSERT INTO `web` VALUES (4, 2, '', '', 0);
INSERT INTO `web` VALUES (5, 2, '', '', 0);
INSERT INTO `web` VALUES (6, 2, '', '', 0);
INSERT INTO `web` VALUES (7, 2, '', '', 0);
INSERT INTO `web` VALUES (8, 2, '', '', 0);
INSERT INTO `web` VALUES (9, 2, '', '', 0);
INSERT INTO `web` VALUES (10, 2, '', '', 0);
INSERT INTO `web` VALUES (11, 2, '', '', 0);
INSERT INTO `web` VALUES (12, 2, '', '', 0);
INSERT INTO `web` VALUES (13, 2, '', '', 0);
INSERT INTO `web` VALUES (14, 2, '', '', 0);
