#SKD101|phao|3|2012.10.12 04:55:02|12|9|2|1

DROP TABLE IF EXISTS `post`;
CREATE TABLE `post` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `idthread` int(10) unsigned NOT NULL default '0',
  `cau` text NOT NULL,
  `noidung` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `post` VALUES
(2, 2, 'bài này là duyệt ma trận kề của đồ thị dùng DFS (đọc ma trận từ file)', '\r\n<p>&nbsp;Duyệt ma trận kề của đồ thị dùng DFS(0 dùng stack) và DFS(có dùng stack) lấy từ file mtke.in dạng như<br> 4<br> 0 1 1 0<br> 1 0 0 1<br> 1 0 0 0<br> 0 1 0 0\r\n</p><p><br></p><p>#include <conio.h><br></conio.h></p> #include <iostream.h><br> #include <stdio.h><br><br> #define MAX 100<br><br>&nbsp;typedef struct {<br> int in;<br> int node[100];<br> }stack;<br><br>&nbsp;void init(stack *s){<br> s-&gt;in=-1;<br> }<br><br>&nbsp;int full(stack *s){<br> if (s-&gt;in==MAX-1) return 1;<br> return 0; <br> }<br><br>&nbsp;int empty(stack *s){<br> if (s-&gt;in==-1) return 1;<br> return 0;<br> }<br><br>&nbsp;void push(stack *s, int x){<br> s-&gt;in=(s-&gt;in)+1;<br> s-&gt;node[s-&gt;in]=x; // báo lỗi ở đây<br> }<br><br>&nbsp;int pop(stack *s){<br> if (empty(s)) return -1;<br> int x=s-&gt;node[s-&gt;in];<br> s-&gt;in=s-&gt;in-1;<br> return x;<br> }<br><br>&nbsp;int viewtop(stack *s){<br> if (empty(s)) return -1;<br> int x;<br> x=s-&gt;node[s-&gt;in];<br> return x;<br> }<br><br> int chuaxet[MAX];<br><br>&nbsp;void DFS(int ke[][MAX],int chuaxet[],int b, int n){<br> int a;<br> cout&lt;&lt;\" \"&lt;<b+1;<br> chuaxet[b]=0;<br> for (a=0; a<n; a++)<br=\"\"> if (chuaxet[a]&amp;&amp;ke[b][a]==1)<br> DFS(ke,chuaxet,a,n);<br> }<br><br>&nbsp;void DFSstack(int ke[][MAX],int chuaxet[],int b, int n){<br> int t,a; stack *s;<br> s= new stack; init(s);<br> push(s,b); chuaxet[b]=0;<br>&nbsp;while (!empty(s)){<br> t=pop(s);<br> cout&lt;&lt;\" \"&lt;<t+1;<br> for (a=0;a<n;a--)<br>&nbsp;if (chuaxet[a]&amp;&amp;ke[t][a]){<br> push(s,a); chuaxet[a]=0;<br>&nbsp;}}}<br><br>&nbsp;main(){<br> int n;<br> FILE *fp;<br> int A[MAX][MAX];<br> fp=fopen(\"mtke.in\",\"r\");<br> if (fp == NULL) cout&lt;&lt;\"File vao khong ton tai\";<br>&nbsp;else{<br> fscanf(fp,\"%d\",&amp;n);<br> cout&lt;&lt;\"So dinh do thi \"&lt;<n<<\" \";<br=\"\"> for (int j=0;j<n;j++) cout<<\"=\"\" \"<<j+1;<br=\"\"> for (int i=0;i<n;i++)<br> {<br> cout&lt;&lt;\"\r\n\"&lt;<i+1;<br> for (int j=0;j<n;j++) {fscanf(fp,\"%d\",&a[i][j]);=\"\" fflush(stdin);=\"\" cout<<\"=\"\" \"<<a[i][j];}<br=\"\">&nbsp;}}<br> for (int i=0;i<n;i++) chuaxet[i]=\"1;<br\"> cout&lt;&lt;\"\r\n\";<br> cout&lt;&lt;\"\r\n\";<br> if (chuaxet[1]) DFS(A,chuaxet,1,n);<br><br> for (int i=0;i<n;i++) chuaxet[i]=\"1;<br\"> cout&lt;&lt;\"\r\n\";<br> cout&lt;&lt;\"\r\n\";<br> if (chuaxet[1]) DFSstack(A,chuaxet,1,n);<br><br> getch(); <br> }<br></n;i++)></n;i++)></n;j++)></i+1;<br></n;i++)<br></n;j++)></n<<\"></n;a--)<br></t+1;<br></n;></b+1;<br></stdio.h></iostream.h>\r\n'),
(3, 2, 'Tìm tất cả các số tự nhiên k thỏa mãn', '\r\nTìm tất cả các số tự nhiên k thỏa mãn:<br>- 5 chữ số\r\n'),
(4, 1, '1. ngăn xếp', '\r\n<p>*Định nghĩa: tập hợp các node thông tin được tổ chức liên tục hoặc rời rạc nhau trog bộ nhớ v  được thực hiện theo cơ chế LIFO (Last in first out)</p><p>*Biểu diễn: giả sử mỗi node thông tin là các số nguyên, stack là tập hợp các node (gồm n phần tử)</p><p>#define MAX 100<br><br>&nbsp;typedef struct {<br> int in;<br>&nbsp;int node[MAX];<br> }stack;</p><p>* Thao tác trên stack:</p><p>Thiết lập trạng thái ban đầu<br>void init(stack *s){<br> s-&gt;in=-1;<br> }<br></p><p>Kiểm tra tính tràn:<br>&nbsp;int full(stack *s){<br> if (s-&gt;in==MAX-1) return 1;<br> return 0; <br> }<br></p><p>Kiểm tra ngăn rỗng:<br>&nbsp;int empty(stack *s){<br> if (s-&gt;in==-1) return 1;<br> return 0;<br> }<br></p><p>Đưa phần tử vào ngăn xếp:<br>&nbsp;void push(stack *s, int x){<br>If (!Full(s)) {<br> s-&gt;in=(s-&gt;in)+1;<br>&nbsp;s-&gt;node[s-&gt;in]=x;<br>}}<br></p><p>Đưa phần tử ra khỏi ngăn xếp:<br> int pop(stack *s)<br> {<br>&nbsp;if (!Empty(s)){<br> int x=s-&gt;node[s-&gt;in];<br>&nbsp;s-&gt;in=(s-&gt;in)-1;<br> return x;<br>&nbsp;}<br>return 0;}<br></p><p>*Ứng dụng: tự tìm hiểu đê</p><p>- Trong biểu diễn tính toán: 1. Dịch sang hậu tố</p><p>p = (a * b + c) - (a+b/c) = (ab*c+)-(abc/+)</p>'),
(5, 1, '2. Hàng đợi', '<br>'),
(6, 1, '3. Danh sách liên kết', '<br>'),
(7, 1, '4.Cây nhị phân', '<br>'),
(8, 1, '5. Đồ thị', '<br>'),
(9, 1, 'Sắp xếp và tìm kiếm', '<br>'),
(10, 1, 'Đệ qui', '<br>');

DROP TABLE IF EXISTS `thread`;
CREATE TABLE `thread` (
  `idthread` int(10) unsigned NOT NULL auto_increment,
  `title` text NOT NULL,
  `edittime` int(10) unsigned NOT NULL default '0',
  `lock` int(1) NOT NULL default '0',
  PRIMARY KEY  (`idthread`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `thread` VALUES
(1, 'Cau truc du lieu', 0, 1),
(2, 'Lap Trinh C', 0, 0);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` text NOT NULL,
  `pass` text NOT NULL,
  `edited` tinyint(3) unsigned NOT NULL default '0',
  `created` tinyint(3) unsigned NOT NULL default '0',
  `deleted` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `users` VALUES
(1, 'khue', 'admin', 1, 1, 1);

