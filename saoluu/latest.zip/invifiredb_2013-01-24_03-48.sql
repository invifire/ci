#SKD101|invifiredb|10|2013.01.24 03:48:27|51|6|22|8|1|14

DROP TABLE IF EXISTS `asset`;
CREATE TABLE `asset` (
  `idasset` bigint(20) unsigned NOT NULL,
  `nameasset` text NOT NULL,
  `url` text NOT NULL,
  `idowner` int(10) unsigned NOT NULL,
  `album` text,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`idasset`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `idbook` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idtile` int(10) unsigned DEFAULT NULL,
  `title` text NOT NULL,
  `noidung` text NOT NULL,
  `author` text NOT NULL,
  `iduser` text NOT NULL,
  `tilestyle` tinyint(4) NOT NULL DEFAULT '0',
  `reviewedtime` int(10) unsigned NOT NULL DEFAULT '0',
  `rating` tinyint(2) unsigned NOT NULL DEFAULT '4',
  `voteup` int(10) unsigned NOT NULL DEFAULT '0',
  `reviewpeople` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `show` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`idbook`)
) ENGINE=MyISAM AUTO_INCREMENT=22 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `book` VALUES
(16, 22, 'THE DAUGHTER OF HUANG CHOW', 'THE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax RohmerTHE DAUGHTER OF HUANG CHOW<br>Sax Rohmer', 'Sax Rohmer', '9', 0, 1352557990, 3, 0, 0, '1'),
(17, 23, 'THE LOST SPECIAL', '', 'Sir Arthur Conan Doyle', '9', 0, 1352558614, 3, 0, 0, '1'),
(18, 24, 'THE STORM OF BADAJOZ', '', 'W.H. Maxwell', '9', 0, 1352558739, 3, 0, 0, '1'),
(19, 25, 'The Lost Trail', '', 'Edward S. Ellis', '9', 0, 1352558888, 3, 0, 0, '1'),
(20, 26, 'Man and Superman', '', 'George Bernard Shaw', '9', 0, 1352558936, 3, 0, 0, '1'),
(21, 27, 'Fred Fearnot\'s Day, or The Great Reunion at Avon', '', 'Hal Standish', '9', 0, 1352559015, 3, 0, 0, '1');

DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `ci_sessions` VALUES
('6240db0421d12676242b7b9a44baa8c7', '180.76.5.157', 'Mozilla/5.0 (Windows NT 5.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2', 1359016673, ''),
('609782d7ccc6de475529b45dd29af0b3', '93.158.147.8', 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)', 1359022216, ''),
('81f62c737963cc54fa819292a1efb512', '93.158.147.8', 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)', 1359022215, ''),
('f6e219c6928de01c5d029f7caf6da7c9', '199.21.99.112', 'Mozilla/5.0 (compatible; YandexBot/3.0; MirrorDetector; +http://yandex.com/bots)', 1359015183, ''),
('c541a83e03603ba1fa7d170eb06d973d', '199.21.99.112', 'Mozilla/5.0 (compatible; YandexBot/3.0; MirrorDetector; +http://yandex.com/bots)', 1359015183, ''),
('ddedc9779986aa8d435354cb3c7d4e9f', '199.21.99.112', 'Mozilla/5.0 (compatible; YandexBot/3.0; MirrorDetector; +http://yandex.com/bots)', 1359015183, ''),
('e1605b5e2788ed1a822bab33a8049573', '199.21.99.112', 'Mozilla/5.0 (compatible; YandexBot/3.0; MirrorDetector; +http://yandex.com/bots)', 1359015183, ''),
('d41995d8c9071b01c285c03c3247b536', '199.21.99.112', 'Mozilla/5.0 (compatible; YandexBot/3.0; MirrorDetector; +http://yandex.com/bots)', 1359015186, ''),
('bb285e65aed5d87bdc670437eefb699f', '199.21.99.112', 'Mozilla/5.0 (compatible; YandexBot/3.0; MirrorDetector; +http://yandex.com/bots)', 1359015186, ''),
('f81e55a08a9f11dd5254d82a93229ffd', '199.21.99.112', 'Mozilla/5.0 (compatible; YandexBot/3.0; MirrorDetector; +http://yandex.com/bots)', 1359015187, ''),
('d653a83e880986739f52cd608b7fce98', '199.21.99.112', 'Mozilla/5.0 (compatible; YandexBot/3.0; MirrorDetector; +http://yandex.com/bots)', 1359015187, ''),
('ae8cf289afe8ae9344e415b5a81a4865', '193.239.255.169', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.12 (KHTML, like Gecko) Maxthon/3.0 Chrome/18.0.966.0 Safari/535.12', 1359016514, ''),
('ab0200278a37b8f3652a54f4c75e228b', '193.239.255.169', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.12 (KHTML, like Gecko) Maxthon/3.0 Chrome/18.0.966.0 Safari/535.12', 1359016514, ''),
('0a8b2ddb2882eecfd5c2ee25ddc53b11', '93.158.147.8', 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)', 1359022215, ''),
('0e0b27b3a2fa5513fcfdf7d9c0b8f686', '93.158.147.8', 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)', 1359022216, ''),
('9f305bd07ad5e9ee2de9078e63fe70a4', '175.44.28.162', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.46 Safari/536.5', 1359022505, ''),
('1828e5541388d5adac17cd98b4920697', '175.44.28.162', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.46 Safari/536.5', 1359022505, ''),
('dfb1b338b0b157f19b454f1ee118837f', '112.111.13.129', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.75 Safari/535.7', 1359024301, ''),
('61aec4588d347d9a78e63c68c3421549', '112.111.13.129', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.75 Safari/535.7', 1359024301, ''),
('e240cb3afd15b76b1998349d012d023b', '93.159.230.14', 'Mozilla/5.0 (Linux; U; Android 2.2; nl-nl; Desire_A8181 Build/FRF91) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 M', 1359017142, ''),
('4a721db7dec7487231daa9ce00397405', '93.159.230.14', 'Mozilla/5.0 (Linux; U; Android 2.2; nl-nl; Desire_A8181 Build/FRF91) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 M', 1359017142, ''),
('cd7af85d7a2f53dde85546982da6d550', '180.76.5.157', 'Mozilla/5.0 (Windows NT 5.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2', 1359016673, '');

DROP TABLE IF EXISTS `grouptile`;
CREATE TABLE `grouptile` (
  `idgroup` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idtile` int(10) unsigned NOT NULL DEFAULT '0',
  `gposition` int(10) unsigned NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `subtitle` text NOT NULL,
  PRIMARY KEY (`idgroup`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `registration_tbl`;
CREATE TABLE `registration_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `tile`;
CREATE TABLE `tile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `iduser` int(10) unsigned NOT NULL DEFAULT '0',
  `position` int(10) unsigned DEFAULT '0',
  `idgroup` int(10) unsigned DEFAULT '0',
  `commentcout` int(10) unsigned DEFAULT '0',
  `imageurl` text,
  `logo` text,
  `brandinfo` text,
  `title` text,
  `subtitle` text,
  `tiletype` text,
  `tilestyle` text,
  `tilestatusnum` int(2) DEFAULT '0',
  `tilestatusimg` int(2) DEFAULT '0',
  `color` text,
  `colorgroup` int(2) DEFAULT '0',
  `anitimeduration` int(2) DEFAULT '0',
  `anitimeperiod` int(2) DEFAULT '0',
  `anitimedirection` int(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `tilebook`;
CREATE TABLE `tilebook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `title` text NOT NULL,
  `sizetile` text NOT NULL,
  `color` text NOT NULL,
  `imageurl` text NOT NULL,
  `commentcout` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `tilebook` VALUES
(29, 9, 'yhtjtj', 'double', 'random', '', 0),
(28, 9, 'Canh dong bat tan', '', 'random', 'images\\5.jpg', 0),
(27, 9, 'Fred Fearnot\'s Day, or The Great Reunion at Avon', 'double', 'random', 'images\\3.jpg', 0),
(26, 9, 'Man and Superman', 'double', 'random', 'images\\3.jpg', 0),
(25, 9, 'The Lost Trail', 'double', 'random', 'images\\3.jpg', 0),
(24, 9, 'THE STORM OF BADAJOZ', 'double', 'random', 'images\\3.jpg', 0),
(23, 9, 'THE LOST SPECIAL', '', 'random', 'images\\3.jpg', 0),
(22, 9, 'THE DAUGHTER OF HUANG CHOW', 'double', 'random', 'images\\b1.jpg', 0);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `iduser` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `pass` text NOT NULL,
  `salt` varchar(255) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `level` int(1) NOT NULL DEFAULT '2',
  `email` text NOT NULL,
  `imageurl` text,
  `ban` int(1) unsigned NOT NULL DEFAULT '0',
  `add_date` datetime DEFAULT NULL,
  `active_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `gender` int(1) NOT NULL,
  PRIMARY KEY (`iduser`)
) ENGINE=MyISAM AUTO_INCREMENT=32 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `users` VALUES
(31, 'First', 'Last', '028c025d69203aa4406882a7d28f56a8', 'eGkkz', 1, 2, 'demo@demo.com', 'images/userdefault.png', 0, '2013-01-01 13:53:49', '2013-01-01 13:53:49', '2013-01-01 13:53:49', 1);

DROP TABLE IF EXISTS `usersdetail`;
CREATE TABLE `usersdetail` (
  `iduser` int(10) unsigned NOT NULL,
  `fav` text NOT NULL,
  `follower` text NOT NULL,
  `following` text NOT NULL,
  `email` text NOT NULL,
  `imgstart` text NOT NULL,
  `imglockscr` text NOT NULL,
  `voteup` int(10) unsigned NOT NULL DEFAULT '0',
  `votedown` int(10) unsigned NOT NULL DEFAULT '0',
  `ban` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`iduser`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `web`;
CREATE TABLE `web` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `iduser` int(10) unsigned NOT NULL DEFAULT '0',
  `web` text NOT NULL,
  `title` text NOT NULL,
  `rating` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `web` VALUES
(1, 2, 'http://www.invifire.com', '<h1>Invifire</h1>', '0'),
(2, 2, 'http://www.iviyshop.com', '', '0'),
(3, 2, 'http://www.invifire.com', '', '0'),
(4, 2, '', '', '0'),
(5, 2, '', '', '0'),
(6, 2, '', '', '0'),
(7, 2, '', '', '0'),
(8, 2, '', '', '0'),
(9, 2, '', '', '0'),
(10, 2, '', '', '0'),
(11, 2, '', '', '0'),
(12, 2, '', '', '0'),
(13, 2, '', '', '0'),
(14, 2, '', '', '0');

