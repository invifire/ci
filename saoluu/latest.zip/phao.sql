-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- http://localhost/

-- Host: localhost
-- Generation Time: Oct 11, 2012 at 01:49 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `phao`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `post`
-- 

DROP TABLE IF EXISTS `grouptile`;
CREATE TABLE IF NOT EXISTS `grouptile` (
  `idgroup` int(10) unsigned NOT NULL auto_increment,
  `idtile` int(10) unsigned NOT NULL default '0',
  `gposition` int(10) unsigned NOT NULL default '0',
  `title` text character set utf8 NOT NULL,
  `subtitle` text character set utf8 NOT NULL,
  PRIMARY KEY  (`idgroup`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=00 ;

-- 
-- -- --------------------------------------------------------

-- 
-- Table structure for table `post`
-- 

DROP TABLE IF EXISTS `tile`;
CREATE TABLE IF NOT EXISTS `tile` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `iduser` int(10) unsigned NOT NULL default '0',
  `position` int(10) unsigned NOT NULL default '0',
  `idgroup` int(10) unsigned NOT NULL default '0',
  `imageurl` text character set utf8 NOT NULL,
  `logo` text character set utf8 NOT NULL,
  `brandinfo` text character set utf8 NOT NULL,
  `title` text character set utf8 NOT NULL,
  `subtitle` text character set utf8 NOT NULL,
  `tiletype` text character set utf8 NOT NULL,
  `tilestyle` text character set utf8 NOT NULL,
  `tilestatusnum` int(2) signed NOT NULL default '0',
  `tilestatusimg` int(2) signed NOT NULL default '0',
  `color` text character set utf8 NOT NULL,
  `colorgroup` int(2) signed NOT NULL default '0',
  `anitimeduration` int(2) signed NOT NULL default '0',
  `anitimeperiod` int(2) signed NOT NULL default '0',
  `anitimedirection` int(2) signed NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;

-- 
-- Dumping data for table `post`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `post`
-- 

DROP TABLE IF EXISTS `web`;
CREATE TABLE IF NOT EXISTS `web` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `iduser` int(10) unsigned NOT NULL default '0',
  `position` int(10) unsigned NOT NULL default '0',
  `web` text character set utf8 NOT NULL,
  `title` text character set utf8 NOT NULL,
  `imageurl` text character set utf8 NOT NULL,
  `tiletype` text character set utf8 NOT NULL,
  `color` text character set utf8 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=00 ;

-- 
-- Dumping data for table `post`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `thread`
-- 

DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `idbook` int(10) unsigned NOT NULL auto_increment,
  `title` text NOT NULL,
  `author` text NOT NULL,
  `iduser` text NOT NULL,
  `dicuss` text NOT NULL,
  `reviewedtime` int(10) unsigned NOT NULL default '0',
  `rating` tinyint(2) unsigned NOT NULL default '4',
  `voteup` int(10) unsigned NOT NULL default '0',
  `reviewpeople` tinyint(2) unsigned NOT NULL default '0',
  `show` float NOT NULL default '1',
  PRIMARY KEY  (`idbook`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;

-- 
-- Dumping data for table `thread`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `iduser` int(10) unsigned NOT NULL auto_increment,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `pass` text NOT NULL,
  `email` text NOT NULL,
  `imageurl` text NOT NULL,
  `created` tinyint(3) unsigned NOT NULL default '0',
  `ban` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`iduser`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `users`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

DROP TABLE IF EXISTS `usersdetail`;
CREATE TABLE IF NOT EXISTS `usersdetail` (
  `iduser` int(10) unsigned NOT NULL,
  `fav` text NOT NULL,
  `follower` text NOT NULL,
  `following` text NOT NULL,
  `email` text NOT NULL,
  `imgstart` text NOT NULL,
  `imglockscr` text NOT NULL,
  `voteup` int(10) unsigned NOT NULL default '0',
  `votedown` int(10) unsigned NOT NULL default '0',
  `ban` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`iduser`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;

-- 
-- Dumping data for table `users`
-- 

